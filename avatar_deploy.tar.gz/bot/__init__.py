"""Bot package."""
